@include('layouts.admin_header')


@yield('main-section')


@include('layouts.admin_footer')
